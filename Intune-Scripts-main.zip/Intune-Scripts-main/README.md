﻿# Intune-Scripts
You can find the blogposts to my scripts here: 
https://jannikreinhard.com/
